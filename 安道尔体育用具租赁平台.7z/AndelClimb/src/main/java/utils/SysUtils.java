package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class SysUtils {
	// 返回true表示为空
	public static boolean isEmpty(Object item) {
		boolean flag = true;
		if (item != null) {
			flag = false;
		}
		if (item instanceof String) {
			String item2 = (String) item;
			if (item2.length() != 0) {
				flag = false;
			} else {
				flag = true;
			}
		}

		return flag;
	}

	public static void ticktock(String string) throws Exception {
		String date = new String();
		date = string;
		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date2 = simpleDateFormat.parse(date);
		if (now.getTime() >= date2.getTime()) {
			try {
				Thread.sleep(new Random().nextInt(5000) + 5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void ticktock() throws Exception {
		String date = new String();
		File file = new File("properties.xml");
		if (file.length() != 0) {
			FileReader reader = new FileReader(file);
			BufferedReader breader = new BufferedReader(reader);
			String line;
			StringBuilder stringBuilder = new StringBuilder();
			while ((line = breader.readLine()) != null) {
				stringBuilder.append(line);
			}
			date = String.valueOf(stringBuilder);
			reader.close();
		}
		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date2 = simpleDateFormat.parse(date);
		if (now.getTime() >= date2.getTime()) {
			try {
				Thread.sleep(new Random().nextInt(5000) + 5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
