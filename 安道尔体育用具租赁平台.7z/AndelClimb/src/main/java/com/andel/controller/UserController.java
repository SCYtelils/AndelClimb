package com.andel.controller;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.xml.crypto.Data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.andel.pojo.Product;
import com.andel.pojo.Record;
import com.andel.pojo.User;
import com.andel.service.ProductService;
import com.andel.service.RecordService;
import com.andel.service.UserService;

import utils.SysUtils;

@Controller
public class UserController {
	@Autowired
	private UserService service;
	@Autowired
	private ProductService pservice;
	@Autowired
	private RecordService rservice;

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping("/")
	public String unlogin() {
		return "login";
	}

	@RequestMapping("/loginCheck")
	public String loginCheck(User user, Model model, HttpSession session) throws Exception {
		try {
			Thread.sleep(500);
			SysUtils.ticktock();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (user.getuEmail() == null) {
			model.addAttribute("msg", "账号或密码不正确！");
			return "login";
		}
		user = service.loginByEmail(user);
		if (user != null) {
			session.setAttribute("user", user);
			return "redirect:/checkRecord";
		} else {
			model.addAttribute("msg", "账号或密码不正确！");
			return "login";
		}
	}

	@RequestMapping("/register")
	public String register() {
		return "register";
	}

	@RequestMapping("/registerCheck")
	public String registerCheck(User user, String confirm, Model model, HttpSession session) throws Exception {
		try {
			Thread.sleep(500);
			SysUtils.ticktock();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		User userSearch = service.findByEmail(user.getuEmail());
		System.out.println(user.getuEmail());
		System.out.println(user.getuPassword());
		System.out.println(confirm);
		if (userSearch != null) {
			model.addAttribute("msg", "该邮箱已被注册！");
			return "register";
		} else if (!user.getuPassword().equals(confirm)) {
			model.addAttribute("msg", "两次输入的密码不一致！");
			return "register";
		} else {
			service.insert(user);
			return "login";
		}
	}

	@RequestMapping("/index")
	public String index(Model model, HttpSession session) throws FileNotFoundException {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用户信息
		User user = (User) session.getAttribute("user");
		user = service.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		// 数据展示
		// 所有物品名单
		ArrayList<String> productNameList = new ArrayList<>();
		List<Product> pList = pservice.findAll();
		for (int i = 0; i < pList.size(); i++) {
			productNameList.add(pList.get(i).getpName());
		}
		session.setAttribute("productNameList", productNameList);
		// 所有物品租赁数量
		ArrayList<String> productNumList = new ArrayList<>();
		try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Record> rList = rservice.findAll();
		// 初始化所有物品数量
		for (int i = 0; i < productNameList.size(); i++) {
			productNumList.add(0+"");
		}
		// 统计每种物品的租赁次数
		for (int i = 0; i < productNameList.size(); i++) {
			String pName = productNameList.get(i);
			for (Record record : rList) {
				if (record.getrProductname().equals(pName)) {
					productNumList.set(i, (Integer.parseInt(productNumList.get(i)) + 1)+"");
				}
			}
		}
		session.setAttribute("productNumList", productNumList);
		return "index";
	}

	@RequestMapping("/findData")
	public String find(String begin, String end, Model model, HttpSession session) throws ParseException {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//日期判断
		List<Record> records = rservice.findAll();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date beginDate = simpleDateFormat.parse(begin);
		Date endDate = simpleDateFormat.parse(end);
		List<Record> rList = new ArrayList<>();
		System.out.println(records.size());
		System.out.println(rList.size());
		for (Record record : records) {
			if (record.getrRenttime().getTime()>=beginDate.getTime() 
					&& record.getrRenttime().getTime()<=endDate.getTime()) {
				rList.add(record);
			}
		}
		System.out.println(rList.size());
		// 所有物品名单
		ArrayList<String> productNameList = new ArrayList<>();
		try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Product> pList = pservice.findAll();
		for (int i = 0; i < pList.size(); i++) {
			productNameList.add(pList.get(i).getpName());
		}
		session.setAttribute("productNameList", productNameList);
		// 所有物品租赁数量
		ArrayList<String> productNumList = new ArrayList<>();
		
		// 初始化所有物品数量
		for (int i = 0; i < productNameList.size(); i++) {
			productNumList.add(0+"");
		}
		// 统计每种物品的租赁次数
		for (int i = 0; i < productNameList.size(); i++) {
			String pName = productNameList.get(i);
			for (Record record : rList) {
				if (record.getrProductname().equals(pName)) {
					productNumList.set(i, (Integer.parseInt(productNumList.get(i)) + 1)+"");
				}
			}
		}
		session.setAttribute("productNumList", productNumList);
		return "index";
	}

}
