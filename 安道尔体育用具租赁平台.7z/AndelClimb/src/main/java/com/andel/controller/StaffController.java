package com.andel.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;

import com.andel.service.StaffService;
import com.andel.service.UserService;
import com.andel.pojo.Staff;
import com.andel.pojo.User;

@Controller
public class StaffController {
	@Autowired
	private StaffService service;
	@Autowired
	private UserService uservice;

	@RequestMapping("/addStaff")
	public String addStaff(Model model, HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		
		return "addStaff";
	}
	@RequestMapping("/checkStaff")
	public String checkStaff(Model model, HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		// 员工显示
		List<Staff> sList = service.findAll();
		model.addAttribute("sList", sList);
		return "checkStaff";
	}
	
	@RequestMapping("/insertStaff")
	public String insertStaff(Staff staff,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.insert(staff);
		return "redirect:/addStaff";
	}
	
	@RequestMapping("/updateStaff")
	public String updateStaff(Integer sId,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Staff staff = new Staff();
		staff = service.findById(sId);
		model.addAttribute("sList", staff);
		return "updateStaff";
	}
	
	@RequestMapping("/excuteStaff")
	public String excuteStaff(Staff staff,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.update(staff);
		return "redirect:/checkStaff";
	}
	
	@RequestMapping("/deleteStaff")
	public String delete(Integer sId,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.delete(sId);
		return "redirect:/checkStaff";
	}

}
