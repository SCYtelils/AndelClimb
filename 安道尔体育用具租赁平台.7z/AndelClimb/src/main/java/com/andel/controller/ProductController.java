package com.andel.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;

import com.andel.service.ProductService;
import com.andel.service.UserService;
import com.andel.pojo.Product;
import com.andel.pojo.User;

@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	@Autowired
	private UserService uservice;

	@RequestMapping("/checkProduct")
	public String checkProduct(Model model, HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		//物品信息显示
		List<Product> pList = service.findAll();
		model.addAttribute("pList", pList);
		return "checkProduct";
	}

	@RequestMapping("/addProduct")
	public String addProduct(Model model, HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		
		return "addproduct";
	}
	
	@RequestMapping("/insertProduct")
	public String insertProduct(Product product,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//计算库存量
		product.setpUseing(0);
		product.setpFree(product.getpTotal()-product.getpUseing());
		//插入数据
		service.insert(product);
		return "redirect:/addProduct";
	}
	
	@RequestMapping("/updateProduct")
	public String updateProduct(Integer pId,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Product product = new Product();
		product = service.findById(pId);
		//物品信息显示
		model.addAttribute("pList", product);
		return "updateProduct";
	}
	
	@RequestMapping("/excuteProduct")
	public String excuteProduct(Product product,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Product origin = new Product();
		origin = service.findById(product.getpId());
		product.setpFree(product.getpTotal()-origin.getpUseing());
		service.update(product);
		return "redirect:/checkProduct";
	}
	
	@RequestMapping("/deleteProduct")
	public String deleteProduct(Integer pId,Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.delete(pId);
		return "redirect:/checkProduct";
	}
	
	@RequestMapping("findByNameProduct")
	public String findByNameProduct(String keywords,Model model,HttpSession session) throws Exception {
		Product product = new Product();
		product.setpName(keywords);
		List<Product> pList = service.find(product);
		model.addAttribute("pList", pList);
		return "checkProduct";
	}
	@RequestMapping("findByCategory")
	public String findByCategory(String pCategory,Model model,HttpSession session) throws Exception {
		Product product = new Product();
		product.setpCategory(pCategory);
		List<Product> pList = service.find(product);
		model.addAttribute("pList", pList);
		return "checkProduct";
	}
	
}
