package com.andel.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.xml.crypto.Data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.andel.pojo.Product;
import com.andel.pojo.Record;
import com.andel.pojo.Staff;
import com.andel.pojo.User;
import com.andel.service.ProductService;
import com.andel.service.RecordService;
import com.andel.service.StaffService;
import com.andel.service.UserService;
@Controller
public class RecordController {
	@Autowired
	private RecordService service;
	@Autowired
	private UserService uservice;
	@Autowired
	private ProductService pservice;
	@Autowired
	private StaffService sservice;
	
	@RequestMapping("/addRecord")
	public String addRecord(Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		//货物显示
		List<Product> pList = pservice.findAll();
		model.addAttribute("pList", pList);
		//职员显示
		List<Staff> sList = sservice.findAll();
		model.addAttribute("sList", sList);
		return "addrecord";
	}
	@RequestMapping("/checkRecord")
	public String checkRecord(Model model,HttpSession session) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//用户显示
		User user = (User) session.getAttribute("user");
		user = uservice.findByEmail(user.getuEmail());
		session.setAttribute("username", user.getuName());
		session.setAttribute("useremail", user.getuEmail());
		//记录显示
		List<Record> rList = service.findAll();
		model.addAttribute("rList", rList);
		return "checkRecord";
	}

	@RequestMapping("/insertRecord")
	public String insertRecord(Record record,Model model,HttpSession session) throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//判断库存量
		Product product = new Product();
		product.setpName(record.getrProductname());
		List<Product> products = pservice.find(product);
		if (products.get(0).getpFree()<=0) {
			session.setAttribute("msg", "该货物已无库存！");
			return "redirect:/addRecord";
		}
		/*
		 * 填充记录信息
		 * 押金金额、借出日期
		 */
		record.setrDeposit(products.get(0).getpDeposit());
		record.setrRenttime(new Date());
		//更改货物库存
		Product excuteProduct = new Product();
		excuteProduct = products.get(0);
		excuteProduct.setpUseing(products.get(0).getpUseing()+1);
		excuteProduct.setpFree(products.get(0).getpTotal()-products.get(0).getpUseing());
		pservice.update(excuteProduct);
		//插入记录
		service.insert(record);
		return "redirect:/addRecord";
	}
	
	@RequestMapping("/returnBack")
	public String returnBack(Record record,Model model,HttpSession session) throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Record> records = service.find(record);
		record = records.get(0);
		//判断状态
		if (record.getrState().equals("租出")) {
			//归还时间
			record.setrReturntime(new Date());
			//租金计算
			Product product = new Product();
			product.setpName(record.getrProductname());
			List<Product> products = pservice.find(product);
			int days = getDistanceTime(record.getrRenttime(), record.getrReturntime());
			record.setrAmount((Integer.parseInt(products.get(0).getpPrice())*(days+1))+".00");
			//更改状态
			record.setrState("已归还");
			//更新库存数据
			Product excuteProduct = new Product();
			excuteProduct = products.get(0);
			excuteProduct.setpUseing(products.get(0).getpUseing()-1);
			excuteProduct.setpFree(products.get(0).getpTotal()-products.get(0).getpUseing());
			pservice.update(excuteProduct);
			//更新数据
			service.update(record);
		}
		return "redirect:/checkRecord";
	}
	
	@RequestMapping("/depositReturnBack")
	public String depositReturnBack(Record record,Model model,HttpSession session) throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<Record> records = service.find(record);
		record = records.get(0);
		//判断状态
		if (record.getrState().equals("租出")) {
			//归还时间
			record.setrReturntime(new Date());
			//租金计算(按照押金金额赔付)
			Product product = new Product();
			product.setpName(record.getrProductname());
			List<Product> products = pservice.find(product);
			record.setrAmount(products.get(0).getpDeposit()+".00");
			//更改状态
			record.setrState("押金赔付");
			//更新库存数据
			Product excuteProduct = new Product();
			excuteProduct = products.get(0);
			excuteProduct.setpUseing(products.get(0).getpUseing()-1);
			excuteProduct.setpFree(products.get(0).getpTotal()-products.get(0).getpUseing());
			pservice.update(excuteProduct);
			//更新数据
			service.update(record);
		}
		return "redirect:/checkRecord";
	}
	
	@RequestMapping("/cancelRecord")
	public String cancelRecord(Integer rId,Model model,HttpSession session) throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Record record = new Record();
		record = service.findById(rId);
		//判断状态，租出状态调整库存，其他状态不调整库存
		if (record.getrState().equals("租出")) {
			Product product = new Product();
			product.setpName(record.getrProductname());
			List<Product> products = pservice.find(product);
			//更新库存数据
			Product excuteProduct = new Product();
			excuteProduct = products.get(0);
			excuteProduct.setpUseing(products.get(0).getpUseing()-1);
			excuteProduct.setpFree(products.get(0).getpTotal()-products.get(0).getpUseing());
			pservice.update(excuteProduct);
		}
		//删除记录
		service.delete(rId);
		return "redirect:/checkRecord";
	}
	
	@RequestMapping("/findByName")
	public String findByName(String keywords,Model model,HttpSession session) throws Exception {
		Record record = new Record();
		record.setrUsername(keywords);
		List<Record> rList = service.find(record);
		model.addAttribute("rList", rList);
		return "/checkRecord";
	}
	
	@RequestMapping("/findByPhone")
	public String findByPhone(String keywords,Model model,HttpSession session) throws Exception {
		Record record = new Record();
		record.setrUserphone(keywords);
		List<Record> rList = service.find(record);
		model.addAttribute("rList", rList);
		return "/checkRecord";
	}

	//以天为单位，计算两个日期的差
	public static int getDistanceTime(Date startTime, Date endTime) {
        int days = 0;
        long time1 = startTime.getTime();
        long time2 = endTime.getTime();

        long diff;
        if (time1 < time2) {
            diff = time2 - time1;
        } else {
            diff = time1 - time2;
        }
        days = (int) (diff / (24 * 60 * 60 * 1000));
        return days;
    }
	
}
