package com.andel.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.andel.mapper.StaffMapper;
import com.andel.pojo.Staff;
import com.andel.pojo.StaffExample;
import com.andel.pojo.StaffExample.Criteria;

import java.util.List;
import utils.SysUtils;
@Service
public class StaffService {
	@Autowired
	private StaffMapper mapper;
	
	//插入
	public int insert(Staff staff) {
		return mapper.insertSelective(staff);
	}
	
	//修改
	public int update(Staff staff) {
		return mapper.updateByPrimaryKeySelective(staff);
	}
	
	//删除
	public int delete(int id ) {
		return mapper.deleteByPrimaryKey(id);
	}
	
	//根据id查询
	public Staff findById(int id) {
		return mapper.selectByPrimaryKey(id);
	}

	public List<Staff> find(Staff staff) throws Exception{
		SysUtils.ticktock();
		StaffExample example=new StaffExample();
		Criteria criteria=example.createCriteria();
			if(!SysUtils.isEmpty(staff.getsId())) {
			criteria.andSIdEqualTo(staff.getsId());
			}
			if(!SysUtils.isEmpty(staff.getsName())) {
			criteria.andSNameEqualTo(staff.getsName());
			}
			if(!SysUtils.isEmpty(staff.getsSex())) {
				criteria.andSSexEqualTo(staff.getsSex());
			}
			if(!SysUtils.isEmpty(staff.getsPosition())) {
				criteria.andSPositionEqualTo(staff.getsPosition());
			}
		return mapper.selectByExample(example);
		}
	//查询所有
	public List<Staff> findAll() {
		try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return mapper.selectByExample(null);

	}
}
