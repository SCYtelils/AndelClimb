package com.andel.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.andel.mapper.UserMapper;
import com.andel.pojo.User;
import com.andel.pojo.UserExample;
import com.andel.pojo.UserExample.Criteria;

import java.util.Date;
import java.util.List;
import utils.SysUtils;
@Service
public class UserService {
	@Autowired
	private UserMapper mapper;
	
	//插入
	public int insert(User user) {
		return mapper.insertSelective(user);
	}
	
	//修改
	public int update(User user) {
		return mapper.updateByPrimaryKeySelective(user);
	}
	
	//删除
	public int delete(String email) {
		return mapper.deleteByPrimaryKey(email);
	}
	//根据名称查询
	public User findByName(User user) {
		UserExample example=new UserExample();
		example.createCriteria().andUNameEqualTo("%"+user.getuName()+"%");
		return mapper.selectByExample(example).get(0);
	}
	
	//根据id查询
	public User findByEmail(String email) {
		return mapper.selectByPrimaryKey(email);
	}

	//查询所有
	public List<User> findAll() {
		return mapper.selectByExample(null);

	}

	public List<User> find(User user) throws Exception{
		UserExample example=new UserExample();
		Criteria criteria=example.createCriteria();
			if(!SysUtils.isEmpty(user.getuName())) {
			criteria.andUNameEqualTo(user.getuName());
			}
			if(!SysUtils.isEmpty(user.getuPassword())) {
			criteria.andUPasswordEqualTo(user.getuPassword());
			}
			if(!SysUtils.isEmpty(user.getuEmail())) {
			criteria.andUEmailEqualTo(user.getuEmail());
			}
		return mapper.selectByExample(example);
		}
//	//以手机登录的查询方式
//	public User loginByPhone(User table) {
//		UserExample example=new UserExample();
//		example.createCriteria().andUserPhoneEqualTo(table.getUserPhone()).andUserPwdEqualTo(table.getUserPwd());
//		return mapper.selectByExample(example).get(0);
//	}
	//以用户名登录的查询方式
	public User loginByEmail(User table) {
		UserExample example=new UserExample();
		example.createCriteria().andUEmailEqualTo(table.getuEmail()).andUPasswordEqualTo(table.getuPassword());try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mapper.selectByExample(example).get(0);
	}
//	//根据手机号查询
//	public User findByPhone(User table) {
//		UserExample example=new UserExample();
//		example.createCriteria().andUserPhoneEqualTo(table.getUserPhone());
//		return mapper.selectByExample(example).get(0);
//	}
//	
//	//根据权限查询
//	public List<User> findByRole(String role){
//		UserExample example=new UserExample();
//		example.createCriteria().andUserRoleEqualTo(role);
//		return mapper.selectByExample(example);
//	}
}
