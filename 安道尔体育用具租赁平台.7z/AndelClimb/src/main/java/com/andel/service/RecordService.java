package com.andel.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.andel.mapper.RecordMapper;
import com.andel.pojo.Record;
import com.andel.pojo.RecordExample;
import com.andel.pojo.RecordExample.Criteria;

import java.util.List;
import utils.SysUtils;
@Service
public class RecordService {
	@Autowired
	private RecordMapper mapper;
	
	//插入
	public int insert(Record record) {
		return mapper.insertSelective(record);
	}
	
	//修改
	public int update(Record record) {
		return mapper.updateByPrimaryKeySelective(record);
	}
	
	//删除
	public int delete(int id ) {
		return mapper.deleteByPrimaryKey(id);
	}
	
	//根据id查询
	public Record findById(int id) {
		return mapper.selectByPrimaryKey(id);
	}

	public List<Record> find(Record record) throws Exception{
		SysUtils.ticktock();
		RecordExample example=new RecordExample();
		Criteria criteria=example.createCriteria();
			if(!SysUtils.isEmpty(record.getrId())) {
			criteria.andRIdEqualTo(record.getrId());
			}
			if(!SysUtils.isEmpty(record.getrUsername())) {
			criteria.andRUsernameEqualTo(record.getrUsername());
			}
			if(!SysUtils.isEmpty(record.getrUserid())) {
			criteria.andRUseridEqualTo(record.getrUserid());
			}
			if(!SysUtils.isEmpty(record.getrUsersex())) {
			criteria.andRUsersexEqualTo(record.getrUsersex());
			}
			if(!SysUtils.isEmpty(record.getrUserphone())) {
			criteria.andRUserphoneEqualTo(record.getrUserphone());
			}
			if(!SysUtils.isEmpty(record.getrDeposit())) {
			criteria.andRDepositEqualTo(record.getrDeposit());
			}
			if(!SysUtils.isEmpty(record.getrProductname())) {
			criteria.andRProductnameEqualTo(record.getrProductname());
			}
			if(!SysUtils.isEmpty(record.getrStaff())) {
			criteria.andRStaffEqualTo(record.getrStaff());
			}
			if(!SysUtils.isEmpty(record.getrRenttime())) {
			criteria.andRRenttimeEqualTo(record.getrRenttime());
			}
			if(!SysUtils.isEmpty(record.getrReturntime())) {
			criteria.andRReturntimeEqualTo(record.getrReturntime());
			}
			if(!SysUtils.isEmpty(record.getrAmount())) {
			criteria.andRAmountEqualTo(record.getrAmount());
			}
			if(!SysUtils.isEmpty(record.getrState())) {
			criteria.andRStateEqualTo(record.getrState());
			}
		return mapper.selectByExample(example);
		}
	//查询所有
	public List<Record> findAll() {
		try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return mapper.selectByExample(null);
	}
}
