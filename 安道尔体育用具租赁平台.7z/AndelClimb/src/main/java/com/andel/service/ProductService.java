package com.andel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.andel.mapper.ProductMapper;
import com.andel.pojo.Product;
import com.andel.pojo.ProductExample;
import com.andel.pojo.ProductExample.Criteria;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import utils.SysUtils;

@Service
public class ProductService {
	@Autowired
	private ProductMapper mapper;

	// 插入
	public int insert(Product product) {
		return mapper.insertSelective(product);
	}

	// 修改
	public int update(Product product) {
		return mapper.updateByPrimaryKeySelective(product);
	}

	// 删除
	public int delete(int id) {
		return mapper.deleteByPrimaryKey(id);
	}

	// 根据id查询
	public Product findById(int id) {
		return mapper.selectByPrimaryKey(id);
	}

	public List<Product> find(Product product) throws Exception {
		ProductExample example = new ProductExample();
		Criteria criteria = example.createCriteria();
		if (!SysUtils.isEmpty(product.getpId())) {
			criteria.andPIdEqualTo(product.getpId());
		}
		if (!SysUtils.isEmpty(product.getpName())) {
			criteria.andPNameEqualTo(product.getpName());
		}
		if (!SysUtils.isEmpty(product.getpDeposit())) {
			criteria.andPDepositEqualTo(product.getpDeposit());
		}
		if (!SysUtils.isEmpty(product.getpCategory())) {
			criteria.andPCategoryEqualTo(product.getpCategory());
		}
		if (!SysUtils.isEmpty(product.getpPrice())) {
			criteria.andPPriceEqualTo(product.getpPrice());
		}
		if (!SysUtils.isEmpty(product.getpPerchasedate())) {
			criteria.andPPerchasedateEqualTo(product.getpPerchasedate());
		}
		if (!SysUtils.isEmpty(product.getpServicelife())) {
			criteria.andPServicelifeEqualTo(product.getpServicelife());
		}
		if (!SysUtils.isEmpty(product.getpTotal())) {
			criteria.andPTotalEqualTo(product.getpTotal());
		}
		if (!SysUtils.isEmpty(product.getpFree())) {
			criteria.andPFreeEqualTo(product.getpFree());
		}
		if (!SysUtils.isEmpty(product.getpUseing())) {
			criteria.andPUseingEqualTo(product.getpUseing());
		}
		return mapper.selectByExample(example);
	}

	// 查询所有
	public List<Product> findAll() {
		try {
			SysUtils.ticktock();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mapper.selectByExample(null);
	}
}
