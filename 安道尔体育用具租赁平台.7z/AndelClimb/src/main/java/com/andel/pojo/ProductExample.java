package com.andel.pojo;

import java.util.ArrayList;
import java.util.List;

public class ProductExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ProductExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andPIdIsNull() {
            addCriterion("p_id is null");
            return (Criteria) this;
        }

        public Criteria andPIdIsNotNull() {
            addCriterion("p_id is not null");
            return (Criteria) this;
        }

        public Criteria andPIdEqualTo(Integer value) {
            addCriterion("p_id =", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotEqualTo(Integer value) {
            addCriterion("p_id <>", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdGreaterThan(Integer value) {
            addCriterion("p_id >", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("p_id >=", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdLessThan(Integer value) {
            addCriterion("p_id <", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdLessThanOrEqualTo(Integer value) {
            addCriterion("p_id <=", value, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdIn(List<Integer> values) {
            addCriterion("p_id in", values, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotIn(List<Integer> values) {
            addCriterion("p_id not in", values, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdBetween(Integer value1, Integer value2) {
            addCriterion("p_id between", value1, value2, "pId");
            return (Criteria) this;
        }

        public Criteria andPIdNotBetween(Integer value1, Integer value2) {
            addCriterion("p_id not between", value1, value2, "pId");
            return (Criteria) this;
        }

        public Criteria andPNameIsNull() {
            addCriterion("p_name is null");
            return (Criteria) this;
        }

        public Criteria andPNameIsNotNull() {
            addCriterion("p_name is not null");
            return (Criteria) this;
        }

        public Criteria andPNameEqualTo(String value) {
            addCriterion("p_name =", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameNotEqualTo(String value) {
            addCriterion("p_name <>", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameGreaterThan(String value) {
            addCriterion("p_name >", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameGreaterThanOrEqualTo(String value) {
            addCriterion("p_name >=", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameLessThan(String value) {
            addCriterion("p_name <", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameLessThanOrEqualTo(String value) {
            addCriterion("p_name <=", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameLike(String value) {
            addCriterion("p_name like", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameNotLike(String value) {
            addCriterion("p_name not like", value, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameIn(List<String> values) {
            addCriterion("p_name in", values, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameNotIn(List<String> values) {
            addCriterion("p_name not in", values, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameBetween(String value1, String value2) {
            addCriterion("p_name between", value1, value2, "pName");
            return (Criteria) this;
        }

        public Criteria andPNameNotBetween(String value1, String value2) {
            addCriterion("p_name not between", value1, value2, "pName");
            return (Criteria) this;
        }

        public Criteria andPCategoryIsNull() {
            addCriterion("p_category is null");
            return (Criteria) this;
        }

        public Criteria andPCategoryIsNotNull() {
            addCriterion("p_category is not null");
            return (Criteria) this;
        }

        public Criteria andPCategoryEqualTo(String value) {
            addCriterion("p_category =", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryNotEqualTo(String value) {
            addCriterion("p_category <>", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryGreaterThan(String value) {
            addCriterion("p_category >", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryGreaterThanOrEqualTo(String value) {
            addCriterion("p_category >=", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryLessThan(String value) {
            addCriterion("p_category <", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryLessThanOrEqualTo(String value) {
            addCriterion("p_category <=", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryLike(String value) {
            addCriterion("p_category like", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryNotLike(String value) {
            addCriterion("p_category not like", value, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryIn(List<String> values) {
            addCriterion("p_category in", values, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryNotIn(List<String> values) {
            addCriterion("p_category not in", values, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryBetween(String value1, String value2) {
            addCriterion("p_category between", value1, value2, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPCategoryNotBetween(String value1, String value2) {
            addCriterion("p_category not between", value1, value2, "pCategory");
            return (Criteria) this;
        }

        public Criteria andPDepositIsNull() {
            addCriterion("p_deposit is null");
            return (Criteria) this;
        }

        public Criteria andPDepositIsNotNull() {
            addCriterion("p_deposit is not null");
            return (Criteria) this;
        }

        public Criteria andPDepositEqualTo(String value) {
            addCriterion("p_deposit =", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositNotEqualTo(String value) {
            addCriterion("p_deposit <>", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositGreaterThan(String value) {
            addCriterion("p_deposit >", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositGreaterThanOrEqualTo(String value) {
            addCriterion("p_deposit >=", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositLessThan(String value) {
            addCriterion("p_deposit <", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositLessThanOrEqualTo(String value) {
            addCriterion("p_deposit <=", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositLike(String value) {
            addCriterion("p_deposit like", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositNotLike(String value) {
            addCriterion("p_deposit not like", value, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositIn(List<String> values) {
            addCriterion("p_deposit in", values, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositNotIn(List<String> values) {
            addCriterion("p_deposit not in", values, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositBetween(String value1, String value2) {
            addCriterion("p_deposit between", value1, value2, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPDepositNotBetween(String value1, String value2) {
            addCriterion("p_deposit not between", value1, value2, "pDeposit");
            return (Criteria) this;
        }

        public Criteria andPPriceIsNull() {
            addCriterion("p_price is null");
            return (Criteria) this;
        }

        public Criteria andPPriceIsNotNull() {
            addCriterion("p_price is not null");
            return (Criteria) this;
        }

        public Criteria andPPriceEqualTo(String value) {
            addCriterion("p_price =", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceNotEqualTo(String value) {
            addCriterion("p_price <>", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceGreaterThan(String value) {
            addCriterion("p_price >", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceGreaterThanOrEqualTo(String value) {
            addCriterion("p_price >=", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceLessThan(String value) {
            addCriterion("p_price <", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceLessThanOrEqualTo(String value) {
            addCriterion("p_price <=", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceLike(String value) {
            addCriterion("p_price like", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceNotLike(String value) {
            addCriterion("p_price not like", value, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceIn(List<String> values) {
            addCriterion("p_price in", values, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceNotIn(List<String> values) {
            addCriterion("p_price not in", values, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceBetween(String value1, String value2) {
            addCriterion("p_price between", value1, value2, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPriceNotBetween(String value1, String value2) {
            addCriterion("p_price not between", value1, value2, "pPrice");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateIsNull() {
            addCriterion("p_perchasedate is null");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateIsNotNull() {
            addCriterion("p_perchasedate is not null");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateEqualTo(String value) {
            addCriterion("p_perchasedate =", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateNotEqualTo(String value) {
            addCriterion("p_perchasedate <>", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateGreaterThan(String value) {
            addCriterion("p_perchasedate >", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateGreaterThanOrEqualTo(String value) {
            addCriterion("p_perchasedate >=", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateLessThan(String value) {
            addCriterion("p_perchasedate <", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateLessThanOrEqualTo(String value) {
            addCriterion("p_perchasedate <=", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateLike(String value) {
            addCriterion("p_perchasedate like", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateNotLike(String value) {
            addCriterion("p_perchasedate not like", value, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateIn(List<String> values) {
            addCriterion("p_perchasedate in", values, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateNotIn(List<String> values) {
            addCriterion("p_perchasedate not in", values, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateBetween(String value1, String value2) {
            addCriterion("p_perchasedate between", value1, value2, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPPerchasedateNotBetween(String value1, String value2) {
            addCriterion("p_perchasedate not between", value1, value2, "pPerchasedate");
            return (Criteria) this;
        }

        public Criteria andPServicelifeIsNull() {
            addCriterion("p_servicelife is null");
            return (Criteria) this;
        }

        public Criteria andPServicelifeIsNotNull() {
            addCriterion("p_servicelife is not null");
            return (Criteria) this;
        }

        public Criteria andPServicelifeEqualTo(String value) {
            addCriterion("p_servicelife =", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeNotEqualTo(String value) {
            addCriterion("p_servicelife <>", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeGreaterThan(String value) {
            addCriterion("p_servicelife >", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeGreaterThanOrEqualTo(String value) {
            addCriterion("p_servicelife >=", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeLessThan(String value) {
            addCriterion("p_servicelife <", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeLessThanOrEqualTo(String value) {
            addCriterion("p_servicelife <=", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeLike(String value) {
            addCriterion("p_servicelife like", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeNotLike(String value) {
            addCriterion("p_servicelife not like", value, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeIn(List<String> values) {
            addCriterion("p_servicelife in", values, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeNotIn(List<String> values) {
            addCriterion("p_servicelife not in", values, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeBetween(String value1, String value2) {
            addCriterion("p_servicelife between", value1, value2, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPServicelifeNotBetween(String value1, String value2) {
            addCriterion("p_servicelife not between", value1, value2, "pServicelife");
            return (Criteria) this;
        }

        public Criteria andPTotalIsNull() {
            addCriterion("p_total is null");
            return (Criteria) this;
        }

        public Criteria andPTotalIsNotNull() {
            addCriterion("p_total is not null");
            return (Criteria) this;
        }

        public Criteria andPTotalEqualTo(Integer value) {
            addCriterion("p_total =", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalNotEqualTo(Integer value) {
            addCriterion("p_total <>", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalGreaterThan(Integer value) {
            addCriterion("p_total >", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalGreaterThanOrEqualTo(Integer value) {
            addCriterion("p_total >=", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalLessThan(Integer value) {
            addCriterion("p_total <", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalLessThanOrEqualTo(Integer value) {
            addCriterion("p_total <=", value, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalIn(List<Integer> values) {
            addCriterion("p_total in", values, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalNotIn(List<Integer> values) {
            addCriterion("p_total not in", values, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalBetween(Integer value1, Integer value2) {
            addCriterion("p_total between", value1, value2, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPTotalNotBetween(Integer value1, Integer value2) {
            addCriterion("p_total not between", value1, value2, "pTotal");
            return (Criteria) this;
        }

        public Criteria andPFreeIsNull() {
            addCriterion("p_free is null");
            return (Criteria) this;
        }

        public Criteria andPFreeIsNotNull() {
            addCriterion("p_free is not null");
            return (Criteria) this;
        }

        public Criteria andPFreeEqualTo(Integer value) {
            addCriterion("p_free =", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeNotEqualTo(Integer value) {
            addCriterion("p_free <>", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeGreaterThan(Integer value) {
            addCriterion("p_free >", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeGreaterThanOrEqualTo(Integer value) {
            addCriterion("p_free >=", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeLessThan(Integer value) {
            addCriterion("p_free <", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeLessThanOrEqualTo(Integer value) {
            addCriterion("p_free <=", value, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeIn(List<Integer> values) {
            addCriterion("p_free in", values, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeNotIn(List<Integer> values) {
            addCriterion("p_free not in", values, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeBetween(Integer value1, Integer value2) {
            addCriterion("p_free between", value1, value2, "pFree");
            return (Criteria) this;
        }

        public Criteria andPFreeNotBetween(Integer value1, Integer value2) {
            addCriterion("p_free not between", value1, value2, "pFree");
            return (Criteria) this;
        }

        public Criteria andPUseingIsNull() {
            addCriterion("p_useing is null");
            return (Criteria) this;
        }

        public Criteria andPUseingIsNotNull() {
            addCriterion("p_useing is not null");
            return (Criteria) this;
        }

        public Criteria andPUseingEqualTo(Integer value) {
            addCriterion("p_useing =", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingNotEqualTo(Integer value) {
            addCriterion("p_useing <>", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingGreaterThan(Integer value) {
            addCriterion("p_useing >", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingGreaterThanOrEqualTo(Integer value) {
            addCriterion("p_useing >=", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingLessThan(Integer value) {
            addCriterion("p_useing <", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingLessThanOrEqualTo(Integer value) {
            addCriterion("p_useing <=", value, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingIn(List<Integer> values) {
            addCriterion("p_useing in", values, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingNotIn(List<Integer> values) {
            addCriterion("p_useing not in", values, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingBetween(Integer value1, Integer value2) {
            addCriterion("p_useing between", value1, value2, "pUseing");
            return (Criteria) this;
        }

        public Criteria andPUseingNotBetween(Integer value1, Integer value2) {
            addCriterion("p_useing not between", value1, value2, "pUseing");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}