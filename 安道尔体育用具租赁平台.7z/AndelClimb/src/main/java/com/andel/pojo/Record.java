package com.andel.pojo;

import java.util.Date;

public class Record {
    private Integer rId;

    private String rUsername;

    private String rUserid;

    private String rUsersex;

    private String rUserphone;

    private String rDeposit;

    private String rProductname;

    private String rStaff;

    private Date rRenttime;

    private Date rReturntime;

    private String rAmount;

    private String rState;

    public Integer getrId() {
        return rId;
    }

    public void setrId(Integer rId) {
        this.rId = rId;
    }

    public String getrUsername() {
        return rUsername;
    }

    public void setrUsername(String rUsername) {
        this.rUsername = rUsername == null ? null : rUsername.trim();
    }

    public String getrUserid() {
        return rUserid;
    }

    public void setrUserid(String rUserid) {
        this.rUserid = rUserid == null ? null : rUserid.trim();
    }

    public String getrUsersex() {
        return rUsersex;
    }

    public void setrUsersex(String rUsersex) {
        this.rUsersex = rUsersex == null ? null : rUsersex.trim();
    }

    public String getrUserphone() {
        return rUserphone;
    }

    public void setrUserphone(String rUserphone) {
        this.rUserphone = rUserphone == null ? null : rUserphone.trim();
    }

    public String getrDeposit() {
        return rDeposit;
    }

    public void setrDeposit(String rDeposit) {
        this.rDeposit = rDeposit == null ? null : rDeposit.trim();
    }

    public String getrProductname() {
        return rProductname;
    }

    public void setrProductname(String rProductname) {
        this.rProductname = rProductname == null ? null : rProductname.trim();
    }

    public String getrStaff() {
        return rStaff;
    }

    public void setrStaff(String rStaff) {
        this.rStaff = rStaff == null ? null : rStaff.trim();
    }

    public Date getrRenttime() {
        return rRenttime;
    }

    public void setrRenttime(Date rRenttime) {
        this.rRenttime = rRenttime;
    }

    public Date getrReturntime() {
        return rReturntime;
    }

    public void setrReturntime(Date rReturntime) {
        this.rReturntime = rReturntime;
    }

    public String getrAmount() {
        return rAmount;
    }

    public void setrAmount(String rAmount) {
        this.rAmount = rAmount == null ? null : rAmount.trim();
    }

    public String getrState() {
        return rState;
    }

    public void setrState(String rState) {
        this.rState = rState == null ? null : rState.trim();
    }
}