package com.andel.pojo;

public class Product {
    private Integer pId;

    private String pName;

    private String pCategory;

    private String pDeposit;

    private String pPrice;

    private String pPerchasedate;

    private String pServicelife;

    private Integer pTotal;

    private Integer pFree;

    private Integer pUseing;

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName == null ? null : pName.trim();
    }

    public String getpCategory() {
        return pCategory;
    }

    public void setpCategory(String pCategory) {
        this.pCategory = pCategory == null ? null : pCategory.trim();
    }

    public String getpDeposit() {
        return pDeposit;
    }

    public void setpDeposit(String pDeposit) {
        this.pDeposit = pDeposit == null ? null : pDeposit.trim();
    }

    public String getpPrice() {
        return pPrice;
    }

    public void setpPrice(String pPrice) {
        this.pPrice = pPrice == null ? null : pPrice.trim();
    }

    public String getpPerchasedate() {
        return pPerchasedate;
    }

    public void setpPerchasedate(String pPerchasedate) {
        this.pPerchasedate = pPerchasedate == null ? null : pPerchasedate.trim();
    }

    public String getpServicelife() {
        return pServicelife;
    }

    public void setpServicelife(String pServicelife) {
        this.pServicelife = pServicelife == null ? null : pServicelife.trim();
    }

    public Integer getpTotal() {
        return pTotal;
    }

    public void setpTotal(Integer pTotal) {
        this.pTotal = pTotal;
    }

    public Integer getpFree() {
        return pFree;
    }

    public void setpFree(Integer pFree) {
        this.pFree = pFree;
    }

    public Integer getpUseing() {
        return pUseing;
    }

    public void setpUseing(Integer pUseing) {
        this.pUseing = pUseing;
    }
}