package com.andel.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RecordExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RecordExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRIdIsNull() {
            addCriterion("r_id is null");
            return (Criteria) this;
        }

        public Criteria andRIdIsNotNull() {
            addCriterion("r_id is not null");
            return (Criteria) this;
        }

        public Criteria andRIdEqualTo(Integer value) {
            addCriterion("r_id =", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdNotEqualTo(Integer value) {
            addCriterion("r_id <>", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdGreaterThan(Integer value) {
            addCriterion("r_id >", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("r_id >=", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdLessThan(Integer value) {
            addCriterion("r_id <", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdLessThanOrEqualTo(Integer value) {
            addCriterion("r_id <=", value, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdIn(List<Integer> values) {
            addCriterion("r_id in", values, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdNotIn(List<Integer> values) {
            addCriterion("r_id not in", values, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdBetween(Integer value1, Integer value2) {
            addCriterion("r_id between", value1, value2, "rId");
            return (Criteria) this;
        }

        public Criteria andRIdNotBetween(Integer value1, Integer value2) {
            addCriterion("r_id not between", value1, value2, "rId");
            return (Criteria) this;
        }

        public Criteria andRUsernameIsNull() {
            addCriterion("r_username is null");
            return (Criteria) this;
        }

        public Criteria andRUsernameIsNotNull() {
            addCriterion("r_username is not null");
            return (Criteria) this;
        }

        public Criteria andRUsernameEqualTo(String value) {
            addCriterion("r_username =", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameNotEqualTo(String value) {
            addCriterion("r_username <>", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameGreaterThan(String value) {
            addCriterion("r_username >", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("r_username >=", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameLessThan(String value) {
            addCriterion("r_username <", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameLessThanOrEqualTo(String value) {
            addCriterion("r_username <=", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameLike(String value) {
            addCriterion("r_username like", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameNotLike(String value) {
            addCriterion("r_username not like", value, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameIn(List<String> values) {
            addCriterion("r_username in", values, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameNotIn(List<String> values) {
            addCriterion("r_username not in", values, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameBetween(String value1, String value2) {
            addCriterion("r_username between", value1, value2, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUsernameNotBetween(String value1, String value2) {
            addCriterion("r_username not between", value1, value2, "rUsername");
            return (Criteria) this;
        }

        public Criteria andRUseridIsNull() {
            addCriterion("r_userid is null");
            return (Criteria) this;
        }

        public Criteria andRUseridIsNotNull() {
            addCriterion("r_userid is not null");
            return (Criteria) this;
        }

        public Criteria andRUseridEqualTo(String value) {
            addCriterion("r_userid =", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridNotEqualTo(String value) {
            addCriterion("r_userid <>", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridGreaterThan(String value) {
            addCriterion("r_userid >", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridGreaterThanOrEqualTo(String value) {
            addCriterion("r_userid >=", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridLessThan(String value) {
            addCriterion("r_userid <", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridLessThanOrEqualTo(String value) {
            addCriterion("r_userid <=", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridLike(String value) {
            addCriterion("r_userid like", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridNotLike(String value) {
            addCriterion("r_userid not like", value, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridIn(List<String> values) {
            addCriterion("r_userid in", values, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridNotIn(List<String> values) {
            addCriterion("r_userid not in", values, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridBetween(String value1, String value2) {
            addCriterion("r_userid between", value1, value2, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUseridNotBetween(String value1, String value2) {
            addCriterion("r_userid not between", value1, value2, "rUserid");
            return (Criteria) this;
        }

        public Criteria andRUsersexIsNull() {
            addCriterion("r_usersex is null");
            return (Criteria) this;
        }

        public Criteria andRUsersexIsNotNull() {
            addCriterion("r_usersex is not null");
            return (Criteria) this;
        }

        public Criteria andRUsersexEqualTo(String value) {
            addCriterion("r_usersex =", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexNotEqualTo(String value) {
            addCriterion("r_usersex <>", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexGreaterThan(String value) {
            addCriterion("r_usersex >", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexGreaterThanOrEqualTo(String value) {
            addCriterion("r_usersex >=", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexLessThan(String value) {
            addCriterion("r_usersex <", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexLessThanOrEqualTo(String value) {
            addCriterion("r_usersex <=", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexLike(String value) {
            addCriterion("r_usersex like", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexNotLike(String value) {
            addCriterion("r_usersex not like", value, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexIn(List<String> values) {
            addCriterion("r_usersex in", values, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexNotIn(List<String> values) {
            addCriterion("r_usersex not in", values, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexBetween(String value1, String value2) {
            addCriterion("r_usersex between", value1, value2, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUsersexNotBetween(String value1, String value2) {
            addCriterion("r_usersex not between", value1, value2, "rUsersex");
            return (Criteria) this;
        }

        public Criteria andRUserphoneIsNull() {
            addCriterion("r_userphone is null");
            return (Criteria) this;
        }

        public Criteria andRUserphoneIsNotNull() {
            addCriterion("r_userphone is not null");
            return (Criteria) this;
        }

        public Criteria andRUserphoneEqualTo(String value) {
            addCriterion("r_userphone =", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneNotEqualTo(String value) {
            addCriterion("r_userphone <>", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneGreaterThan(String value) {
            addCriterion("r_userphone >", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneGreaterThanOrEqualTo(String value) {
            addCriterion("r_userphone >=", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneLessThan(String value) {
            addCriterion("r_userphone <", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneLessThanOrEqualTo(String value) {
            addCriterion("r_userphone <=", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneLike(String value) {
            addCriterion("r_userphone like", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneNotLike(String value) {
            addCriterion("r_userphone not like", value, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneIn(List<String> values) {
            addCriterion("r_userphone in", values, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneNotIn(List<String> values) {
            addCriterion("r_userphone not in", values, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneBetween(String value1, String value2) {
            addCriterion("r_userphone between", value1, value2, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRUserphoneNotBetween(String value1, String value2) {
            addCriterion("r_userphone not between", value1, value2, "rUserphone");
            return (Criteria) this;
        }

        public Criteria andRDepositIsNull() {
            addCriterion("r_deposit is null");
            return (Criteria) this;
        }

        public Criteria andRDepositIsNotNull() {
            addCriterion("r_deposit is not null");
            return (Criteria) this;
        }

        public Criteria andRDepositEqualTo(String value) {
            addCriterion("r_deposit =", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositNotEqualTo(String value) {
            addCriterion("r_deposit <>", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositGreaterThan(String value) {
            addCriterion("r_deposit >", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositGreaterThanOrEqualTo(String value) {
            addCriterion("r_deposit >=", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositLessThan(String value) {
            addCriterion("r_deposit <", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositLessThanOrEqualTo(String value) {
            addCriterion("r_deposit <=", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositLike(String value) {
            addCriterion("r_deposit like", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositNotLike(String value) {
            addCriterion("r_deposit not like", value, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositIn(List<String> values) {
            addCriterion("r_deposit in", values, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositNotIn(List<String> values) {
            addCriterion("r_deposit not in", values, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositBetween(String value1, String value2) {
            addCriterion("r_deposit between", value1, value2, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRDepositNotBetween(String value1, String value2) {
            addCriterion("r_deposit not between", value1, value2, "rDeposit");
            return (Criteria) this;
        }

        public Criteria andRProductnameIsNull() {
            addCriterion("r_productname is null");
            return (Criteria) this;
        }

        public Criteria andRProductnameIsNotNull() {
            addCriterion("r_productname is not null");
            return (Criteria) this;
        }

        public Criteria andRProductnameEqualTo(String value) {
            addCriterion("r_productname =", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameNotEqualTo(String value) {
            addCriterion("r_productname <>", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameGreaterThan(String value) {
            addCriterion("r_productname >", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameGreaterThanOrEqualTo(String value) {
            addCriterion("r_productname >=", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameLessThan(String value) {
            addCriterion("r_productname <", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameLessThanOrEqualTo(String value) {
            addCriterion("r_productname <=", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameLike(String value) {
            addCriterion("r_productname like", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameNotLike(String value) {
            addCriterion("r_productname not like", value, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameIn(List<String> values) {
            addCriterion("r_productname in", values, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameNotIn(List<String> values) {
            addCriterion("r_productname not in", values, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameBetween(String value1, String value2) {
            addCriterion("r_productname between", value1, value2, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRProductnameNotBetween(String value1, String value2) {
            addCriterion("r_productname not between", value1, value2, "rProductname");
            return (Criteria) this;
        }

        public Criteria andRStaffIsNull() {
            addCriterion("r_staff is null");
            return (Criteria) this;
        }

        public Criteria andRStaffIsNotNull() {
            addCriterion("r_staff is not null");
            return (Criteria) this;
        }

        public Criteria andRStaffEqualTo(String value) {
            addCriterion("r_staff =", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffNotEqualTo(String value) {
            addCriterion("r_staff <>", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffGreaterThan(String value) {
            addCriterion("r_staff >", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffGreaterThanOrEqualTo(String value) {
            addCriterion("r_staff >=", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffLessThan(String value) {
            addCriterion("r_staff <", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffLessThanOrEqualTo(String value) {
            addCriterion("r_staff <=", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffLike(String value) {
            addCriterion("r_staff like", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffNotLike(String value) {
            addCriterion("r_staff not like", value, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffIn(List<String> values) {
            addCriterion("r_staff in", values, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffNotIn(List<String> values) {
            addCriterion("r_staff not in", values, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffBetween(String value1, String value2) {
            addCriterion("r_staff between", value1, value2, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRStaffNotBetween(String value1, String value2) {
            addCriterion("r_staff not between", value1, value2, "rStaff");
            return (Criteria) this;
        }

        public Criteria andRRenttimeIsNull() {
            addCriterion("r_renttime is null");
            return (Criteria) this;
        }

        public Criteria andRRenttimeIsNotNull() {
            addCriterion("r_renttime is not null");
            return (Criteria) this;
        }

        public Criteria andRRenttimeEqualTo(Date value) {
            addCriterion("r_renttime =", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeNotEqualTo(Date value) {
            addCriterion("r_renttime <>", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeGreaterThan(Date value) {
            addCriterion("r_renttime >", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeGreaterThanOrEqualTo(Date value) {
            addCriterion("r_renttime >=", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeLessThan(Date value) {
            addCriterion("r_renttime <", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeLessThanOrEqualTo(Date value) {
            addCriterion("r_renttime <=", value, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeIn(List<Date> values) {
            addCriterion("r_renttime in", values, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeNotIn(List<Date> values) {
            addCriterion("r_renttime not in", values, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeBetween(Date value1, Date value2) {
            addCriterion("r_renttime between", value1, value2, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRRenttimeNotBetween(Date value1, Date value2) {
            addCriterion("r_renttime not between", value1, value2, "rRenttime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeIsNull() {
            addCriterion("r_returntime is null");
            return (Criteria) this;
        }

        public Criteria andRReturntimeIsNotNull() {
            addCriterion("r_returntime is not null");
            return (Criteria) this;
        }

        public Criteria andRReturntimeEqualTo(Date value) {
            addCriterion("r_returntime =", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeNotEqualTo(Date value) {
            addCriterion("r_returntime <>", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeGreaterThan(Date value) {
            addCriterion("r_returntime >", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeGreaterThanOrEqualTo(Date value) {
            addCriterion("r_returntime >=", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeLessThan(Date value) {
            addCriterion("r_returntime <", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeLessThanOrEqualTo(Date value) {
            addCriterion("r_returntime <=", value, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeIn(List<Date> values) {
            addCriterion("r_returntime in", values, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeNotIn(List<Date> values) {
            addCriterion("r_returntime not in", values, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeBetween(Date value1, Date value2) {
            addCriterion("r_returntime between", value1, value2, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRReturntimeNotBetween(Date value1, Date value2) {
            addCriterion("r_returntime not between", value1, value2, "rReturntime");
            return (Criteria) this;
        }

        public Criteria andRAmountIsNull() {
            addCriterion("r_amount is null");
            return (Criteria) this;
        }

        public Criteria andRAmountIsNotNull() {
            addCriterion("r_amount is not null");
            return (Criteria) this;
        }

        public Criteria andRAmountEqualTo(String value) {
            addCriterion("r_amount =", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountNotEqualTo(String value) {
            addCriterion("r_amount <>", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountGreaterThan(String value) {
            addCriterion("r_amount >", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountGreaterThanOrEqualTo(String value) {
            addCriterion("r_amount >=", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountLessThan(String value) {
            addCriterion("r_amount <", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountLessThanOrEqualTo(String value) {
            addCriterion("r_amount <=", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountLike(String value) {
            addCriterion("r_amount like", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountNotLike(String value) {
            addCriterion("r_amount not like", value, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountIn(List<String> values) {
            addCriterion("r_amount in", values, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountNotIn(List<String> values) {
            addCriterion("r_amount not in", values, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountBetween(String value1, String value2) {
            addCriterion("r_amount between", value1, value2, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRAmountNotBetween(String value1, String value2) {
            addCriterion("r_amount not between", value1, value2, "rAmount");
            return (Criteria) this;
        }

        public Criteria andRStateIsNull() {
            addCriterion("r_state is null");
            return (Criteria) this;
        }

        public Criteria andRStateIsNotNull() {
            addCriterion("r_state is not null");
            return (Criteria) this;
        }

        public Criteria andRStateEqualTo(String value) {
            addCriterion("r_state =", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateNotEqualTo(String value) {
            addCriterion("r_state <>", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateGreaterThan(String value) {
            addCriterion("r_state >", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateGreaterThanOrEqualTo(String value) {
            addCriterion("r_state >=", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateLessThan(String value) {
            addCriterion("r_state <", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateLessThanOrEqualTo(String value) {
            addCriterion("r_state <=", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateLike(String value) {
            addCriterion("r_state like", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateNotLike(String value) {
            addCriterion("r_state not like", value, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateIn(List<String> values) {
            addCriterion("r_state in", values, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateNotIn(List<String> values) {
            addCriterion("r_state not in", values, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateBetween(String value1, String value2) {
            addCriterion("r_state between", value1, value2, "rState");
            return (Criteria) this;
        }

        public Criteria andRStateNotBetween(String value1, String value2) {
            addCriterion("r_state not between", value1, value2, "rState");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}